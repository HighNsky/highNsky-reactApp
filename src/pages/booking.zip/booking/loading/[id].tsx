import Header from "@/components/layouts/BasicLayout/Header";
import { liveurl } from "@/hostUrl";
import axios from "axios";
import { useAtom } from "jotai";
import { Router, useRouter } from "next/router";
import React, { useEffect } from "react";


const Loading = () => {
    const router = useRouter();
    const rideIdNo=router.query.id

    console.log('rideIdNo', rideIdNo)
    if (typeof window !== 'undefined') {
    var rideid =window.sessionStorage.getItem("userRideId")
//   let guest = JSON.parse(sessionStorage.getItem("guestData"));
//   const navigate = useNavigate();
    // const { vehicle } = useParams();
    }
    const callMe = () => {
      axios
        .get(`${liveurl}/api/passenger/me`, {
          headers: { Authorization: localStorage.getItem("accessToken") },
        })
        ?.then((res) => {
          handleUpdateRide(res?.data);
          console.log("res?.data", res?.data);
        });
    };
  
  const handleUpdateRide = (user:any) => {
    // console.log('object', object)
    const body = {
 

      rideID: rideid,
      // carId: vehicle,
      firstName: user?.data?.name ,
      email: user?.data?.email ,
      phoneNo: user?.data?.phone ,
      countryCode: user?.data?.countryCode || "",
      lastName: user?.data?.lastName || "",
    };

  

    axios
      .put(
        `${liveurl}/api/adminPanel/rides/updateRide?status=paymentUpdate`,
        body
      )
      .then((res) => {
        console.log(body, "body 2");
        if (res?.data?.success === true) {
            // router.push("http://localhost:3000/");
              router.push("/booking/myRides");
        //   navigate("/booking/myrides");
        }
      })
      .catch((error) => {
        console.log(error);
      });
  };
  

  useEffect(() => {
    callMe();
  }, []);

  return (
    <div>
      <div className="">
        <Header />
      </div>
      <div className="bg-white w-screen h-[70px] absolute top-0"></div>
      <div className="mainbod z-10">
        <div className="loadingloader">
          <span className="xxs:text-[15px] xs:text-3xl">Redirecting</span>
        </div>
      </div>
    </div>
  );
};

export default Loading;
