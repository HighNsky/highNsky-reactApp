import React, { useEffect, useState } from "react";

import { FaShoppingBag } from "react-icons/fa";
import { HiUserGroup } from "react-icons/hi";
import { ImLocation2 } from "react-icons/im";
import { AiTwotoneStar } from "react-icons/ai";
import { meUser } from "../../../store/jotaiModal";

import Myride from "../../../images/Myride.png";
import { useAtom } from "jotai";
import axios from "axios";
import { liveurl } from "../../../hostUrl";
import Link from "next/link";
import Image from "next/image";

// import Loader from "../../../component/Loader";

const MyRides = () => {
  const [div, setDiv] = useState(false);
  const [rideId, setRideId] = useState("");
  const [user]: any = useAtom(meUser);
  const [myRides, setMyRides] = useState([]);
  const [loading, setLoading] = useState(false);
  console.log("user", user);
  // const { email } = useParams();
  // let guest = sessionStorage.getItem("guestData");
  const emailz = user?.data?.email;
  console.log("ride", emailz);
  // let guestParse = JSON.parse(guest);
  const url = `${liveurl}/api/passenger/getAllBookedRides?status=Upcoming&email=${emailz}`;
  useEffect(() => {
    if (div) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
  }, [div]);

  useEffect(() => {
    setLoading(true);
    if (emailz) {
      axios

        .get(
          url,

          {
            headers: { Authorization: localStorage.getItem("accessToken") },
          }
        )
        .then((res) => {
          setMyRides(res?.data?.data);
          setLoading(false);
        })
        .catch((error) => {
          console.log(error, "errors");
          setLoading(false);
        });
    }
    window.sessionStorage.removeItem("userRideId");
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  }, []);

  const fetchData = () => {
    setLoading(true);
    setDiv(false);
    axios
      .get(url, {
        headers: { Authorization: localStorage.getItem("accessToken") },
      })
      .then((res) => {
        setMyRides(res?.data?.data);
        setLoading(false);
      })
      .catch((error) => {
        console.log(error, "errors");
        setLoading(false);
      });
  };

  const Handlediv = (id) => {
    setDiv(!div);
  };
  const HandleThanks = () => {
    setDiv(!div);
    setRideId("");
  };
  const handleCancelRide = () => {
    const body = { rideID: rideId };
    axios
      .put(`${liveurl}/api/adminPanel/rides/updateRide?status=cancel`, body)
      .then((res) => {
        if (res?.data?.message === "Ride updated successfully.") {
          fetchData();
          // window.location.reload();
        }
      })
      .catch((error) => {});
  };

  const Array = [
    {
      para: "If booking is cancelled before 24 hours of service, 100% refund will be applied.",
    },
    {
      para: "If booking is cancelled within 24 hours of service, 50% refund will be applied.",
    },
  ];

  return (
    <div>
      {loading ? (
        <div className=" bg-transparent z-[1] absolute w-[100%] h-screen">
          <div className="flex justify-center bg-white h-screen">
            {/* <Loader /> */}
          </div>
        </div>
      ) : (
        <div>
          <div className="bredcrumbs-div wf-section"></div>
          <div className="breadcrumb wf-section ">
            <h1 className="heading-7225">
              <strong className="bold-text-252">Your Bookings</strong>
            </h1>
          </div>

          <div>
            {user?.data?.email && myRides?.length === 0 && (
              <div className="flex flex-col justify-center items-center my-12">
                <div className="text-4xl text-gray-400">No Bookings Yet33</div>{" "}
                <div className="  mt-2 hover:text-white">

                  <Link
                  href="/booknowform"
                    // to={"/booking"}
                    data-w-id="59022d57-fe81-c57e-9c20-af575f9567d8"
                    className="button-211174 w-button"
                  >
                    Book Now!
                  </Link>
                </div>
              </div>
            )}
            {!user?.data?.email && (
              <div className="flex flex-col justify-center items-center my-12">
                <div className="text-4xl text-gray-400">
                  Login to see your bookings
                </div>{" "}
                <div className="  mt-2 hover:text-white">
                  {/* <Link
                    // to={"/login"}
                    data-w-id="59022d57-fe81-c57e-9c20-af575f9567d8"
                    className="button-211174 w-button"
                  >
                    Login
                  </Link> */}
                </div>
              </div>
            )}
            {myRides?.map((val) => (
              <>
                <div className="flex flex-col rounded-lg bg-white shadow-xl border dark:bg-neutral-700 md:max-w-7xl   md:h-[300px] md:flex-row mx-auto mt-10">
                  <img
                    className="h-[320px] w-[500px] object-fill md:h-auto md:w-[600px]   bg-gray-200  "
                    src={val?.vehicleDetails?.vehicleImage?.url}
                    alt=""
                  />

                  <div className="flex flex-col justify-start p-6">
                    <h5 className="mb-2 text-xl ">
                      <ImLocation2 className="text-black h-6 w-6  font-thin   " />
                      Pickup
                    </h5>
                    <p className="mb-4 text-base">{val?.pickupLocation}</p>

                    <p className="text-md p-3 justify-evenly text-center  flex flex-row gap-20 ">
                      <div className=" p-1 flex flex-row gap-2 w-1/2 text-start text-[#555]">
                        <div>
                          <HiUserGroup className="h-6 w-6  " />
                        </div>
                        max {val?.vehicleDetails?.seats}
                      </div>
                      <div className="  p-1  flex flex-row gap-2 w-1/2 text-start text-[#555]">
                        <div>
                          <FaShoppingBag className="h-6 w-6" />
                        </div>
                        max {val?.vehicleDetails?.luggageQuantity}
                      </div>
                    </p>

                  </div>

                  <div
                      onClick={() => {
                        Handlediv();
                        setRideId(val?._id);
                      }}
                      className="bg-yellow-600 cursor-pointer md:h-[50px]  text-center text-xl text-white p-2 px-5 w-[100px] place-self-end mb-10 mr-10 ml-auto rounded-md border hover:bg-yellow-500  "
                    >
                      Cancel
                    </div>
                </div>
              </>
            ))}
          </div>

          {div && (
            <div
              className="h-full w-full fixed left-[0%] top-1  rounded-lg flex justify-center"
              style={{
                backdropFilter: "blur(5px)",
              }}
            >
              <div
                className="  pb-10 relative  xxxs:mx-2  border w-fit h-fit sm:mx-[4rem]  lg:mx-[16rem] xl:mx-[2rem] top-1  rounded-lg bg-white  "
                style={{
                  boxShadow:
                    "rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
                }}
              >
                <div className="text-center text-[25px] mt-5 pt-5">
                  Our Policy
                </div>
                <div>
                  {Array.map((item) => (
                    <div className="mt-5    md:px-6">
                      <div className="flex gap-2  px-10 py-5 ">
                        <div>
                          <AiTwotoneStar className="text-[25px] text-yellow-600" />
                        </div>
                        <div className="font-normal">{item.para}</div>
                      </div>
                    </div>
                  ))}

                  <div className=" flex  md:gap-10 xxs:flex-wrap xxs:justify-center md:justify-between md:mx-[2rem]  p-5  relative   top-5 ">
                    <div
                      className="border border-red-600 w-fit  p-2 rounded-md cursor-pointer bg-red-500 text-white mb-5"
                      onClick={() => {
                        handleCancelRide();
                      }}
                    >
                      Yes, I want to Cancel
                    </div>
                    <div
                      onClick={HandleThanks}
                      className="border w-fit border-blue-600 p-2 rounded-md cursor-pointer bg-blue-600 text-white mb-5 ml-5"
                    >
                      No Thanks
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default MyRides;
