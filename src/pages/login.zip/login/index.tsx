import axios, { HttpStatusCode } from "axios";
import React, { useEffect } from "react";

// import { Link, useNavigate } from "react-router-dom";
import loginlogo from "../../assets/images/logo.png"
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { liveurl } from "../../hostUrl";
import Link from "next/link";
import Header from "@/components/layouts/BasicLayout/Header";


// import Header from "../../Header";
// import Loader from "../../component/Loader";

const LogInForm = () => {
//   const navigate = useNavigate();
  const [{ email, password }, setLogin] = useState("");
  const [errors, setErrors] = useState("");
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 200);
  }, []);

  const handleFormSubmit = (e) => {
    const { value, name } = e.target;
    setLogin((curr) => ({ ...curr, [name]: value }));
  };
  const handleToast = () => {
    toast.error("Incorrect username or password. Please try again.", {
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme: "light",
    });
  };

  const handleSubmit = () => {
    axios
      .post(`${liveurl}/api/passenger/login`, {
        email: email,
        password: password,
      })
      .then(async (res) => {
        if (res?.data?.success) {
          window.localStorage.setItem("accessToken", res?.data?.accessToken);

          const rideId = await window.sessionStorage.getItem("userRideId");

          console.log(
            res.data.user?._id,
            "iddddddddddddddddddddddddddddddddddddddd",
            rideId
          );

          if (res?.data?.accessToken && rideId) {
            navigate("/vehicle");
            console.log("biiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
          } else if (res?.data?.accessToken) {
            navigate("/");
          }
        }
        sessionStorage.removeItem("guestData");

        setLogin({ email: "", password: "" });
        toast("wow!");
      })
      .catch((error) => {
        handleToast();
      });
  };
  return (
    <div>
      {loading ? (
        <div className=" bg-transparent z-[1] absolute w-[100%] h-screen">
          <div className="flex justify-center bg-white h-screen">
            {/* <Loader /> */}
          </div>
        </div>
      ) : (
        <div>
          <Header />
          <ToastContainer />
          <div className="breadcrumb  wf-section">
            <h1
              data-w-id="1b23df6a-e44d-a5b5-7bd3-b0f7d3e1d223"
              className="heading-7225"
            >
              <AnimatePresence>
                <motion.div
                  data-w-id="b931e2c9-2b60-65e5-58e8-5834c2ccf676"
                  className="login-form p-2 h-[20px]"
                  initial={{ y: 100, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ duration: 1.4 }}
                >
                  <div className="link-block-63 w-inline-block">
                    <div className="logo-2">
                      <img
                        src={loginlogo}
                        loading="lazy"
                        alt=""
                        className="image-32442"
                      />
                    </div>
                  </div>
                  <div>
                    <h1 className=" text-center text-[25px] font-[Cinzel]">
                      Login
                    </h1>
                  </div>
                  <div className="form-11 p-[20px] ">
                    <div className="form-block-7 w-form">
                      <form
                        id="email-form"
                        name="email-form"
                        data-name="Email Form"
                        method="get"
                        className="form-10"
                      >
                        <label for="email-3" className="field-label-7">
                          Email
                        </label>
                        <input
                          type="email"
                          className="login-input w-input rounded-md mb-2 text-black"
                          name="email"
                          onChange={handleFormSubmit}
                          value={email}
                          placeholder=""
                          id="email-3"
                          required=""
                        />

                        <label for="email-2" className="field-label-6">
                          Password
                        </label>
                        <input
                          type="password"
                          name="password"
                          className="login-input w-input rounded-md text-black"
                          placeholder=""
                          required=""
                          onChange={handleFormSubmit}
                          value={password}
                        />
                      </form>
                    </div>
                  </div>
                  <button
                    className="button-211150 w-button rounded-[25px] "
                    onClick={() => handleSubmit()}
                  >
                    LogIn
                  </button>
                  <div
                    className="pass text font-semibold flex justify-center cursor-pointer"
                    // onClick={() => {
                    //   navigate("/forgotpassword/forgotemail");
                    // }}
                  >
                    Forgot Password
                  </div>
                  <div className="div-block-31005  relative bottom-3">
                    <Link href="/signup" className="link-133 font-sans">
                      <strong className="bold-text-250">
                        Not have an account yet
                      </strong>{" "}
                      <strong className="bold-text-250">?</strong>{" "}
                      {/* <Link href="/signup"> */}
                        <strong className="bold-text-250">Sign Up</strong>
                      {/* </Link> */}
                    </Link>
                  </div>
                </motion.div>
              </AnimatePresence>
            </h1>
          </div>
        </div>
      )}
    </div>
  );
};

export default LogInForm;
